const { MessageEmbed } = require('discord.js');

const { color } = require('../../config.json')

module.exports = {

	name: 'about',

	description: "Donne les différents réseaux sociaux du développeur.",

    category: "🤖・bot",

     botPermission: [], 

     authorPermission: [], 

     ownerOnly: false,

    

     aliases: [],

    

    

	run: async (client, message, args) => {

    let embed = new MessageEmbed()

    

    .setTitle('Voici les différents réseaux sociaux !')
    
   .addField('<:snap:947966221645656074> Snapchat','fhairon08 | [lien](https://www.snapchat.com/add/fhairon8?share_id=hyQDyF9yI64&locale=fr-FR)', true)
    
   .addField('<:insta:947966769363058718> Instagram', 'tentation_bot | [lien](https://www.instagram.com/tentation_bot/)', true)
    
   .addField('<:tiktok:947967283211431946> Tiktok', 'f.e.n.r.y.l_08 | [lien](https://vm.tiktok.com/ZMLA17Bsy/)', true)
    
   .addField('<:discord:947968136811016292> Discord', '🫀・French.#2352', true)
    
   .addField('<:twitter:947968900434374696> Twitter', 'fhairon08 | [lien](https://twitter.com/fhairon08?t=1p-cYhjUrIaLr2VK-_cBow&s=09)', true)
   
   .addField('<:paypal:947976759649914940> PayPal', 'fenryllol | [lien](https://www.paypal.me/fenryllol)', true)
    

    .setColor(color)

    .setFooter('Développer par 🫀・French.')
    
    .setTimestamp();

        

   message.channel.send(embed);

    }

};